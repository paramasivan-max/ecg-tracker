export const mockEcgWaveform = () => {
  const data = [];
  for (let i = 0; i < 100; i++) {
    let value = 0;
    if (i % 20 === 15) value = 0.8; // R peak
    else if (i % 20 === 14 || i % 20 === 16) value = -0.2; // Q and S
    else if (i % 20 === 17) value = 0.3; // T wave
    else value = Math.random() * 0.1 - 0.05; // baseline noise
    
    data.push({ x: i, y: value });
  }
  return data;
};

export const mockHeartRateTrend = () => {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const heartRateData = [72, 68, 75, 70, 74, 69, 73];
  
  return {
    labels: days,
    data: heartRateData,
  };
};

export const generateCsvData = (readings: any[]) => {
  const csvData = [
    ['Date', 'Time', 'Heart Rate', 'Status', 'Duration'],
    ...readings.map(reading => [
      new Date(reading.timestamp).toLocaleDateString(),
      new Date(reading.timestamp).toLocaleTimeString(),
      `${reading.heartRate}`,
      reading.status,
      `${reading.duration}s`
    ])
  ];
  
  return csvData.map(row => row.join(',')).join('\n');
};

export const downloadCsv = (csvContent: string, filename: string = 'ecg_history.csv') => {
  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  
  window.URL.revokeObjectURL(url);
};
