import { type User } from "@shared/schema";

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
}

export function getStoredUser(): User | null {
  try {
    const stored = localStorage.getItem("currentUser");
    return stored ? JSON.parse(stored) : null;
  } catch {
    return null;
  }
}

export function setStoredUser(user: User | null): void {
  if (user) {
    localStorage.setItem("currentUser", JSON.stringify(user));
  } else {
    localStorage.removeItem("currentUser");
  }
}

export function clearAuth(): void {
  localStorage.removeItem("currentUser");
}
