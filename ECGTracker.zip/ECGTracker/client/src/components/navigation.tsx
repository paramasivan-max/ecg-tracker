import { Link, useLocation } from "wouter";
import { Activity, History, User, LogOut, Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "./theme-provider";
import { clearAuth } from "@/lib/auth";
import { cn } from "@/lib/utils";

interface NavigationProps {
  onLogout: () => void;
}

export function Navigation({ onLogout }: NavigationProps) {
  const [location] = useLocation();
  const { theme, toggleTheme } = useTheme();

  const handleLogout = () => {
    clearAuth();
    onLogout();
  };

  const navItems = [
    { path: "/dashboard", icon: Activity, label: "Dashboard", testId: "nav-dashboard" },
    { path: "/history", icon: History, label: "History", testId: "nav-history" },
    { path: "/profile", icon: User, label: "Profile", testId: "nav-profile" },
  ];

  return (
    <>
      {/* Dark Mode Toggle */}
      <Button
        variant="outline"
        size="icon"
        onClick={toggleTheme}
        className="fixed top-4 right-4 z-50 bg-card border border-border shadow-lg"
        data-testid="button-toggle-theme"
      >
        {theme === "dark" ? (
          <Sun className="h-5 w-5" />
        ) : (
          <Moon className="h-5 w-5" />
        )}
      </Button>

      {/* Mobile Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50 md:top-0 md:bottom-auto md:border-b md:border-t-0">
        <div className="flex justify-around md:justify-center md:space-x-8 py-2 md:py-4 px-4">
          {navItems.map((item) => {
            const isActive = location === item.path;
            const Icon = item.icon;
            
            return (
              <Link key={item.path} href={item.path}>
                <button
                  className={cn(
                    "flex flex-col md:flex-row items-center space-y-1 md:space-y-0 md:space-x-2 px-3 py-2 rounded-lg transition-colors",
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-muted"
                  )}
                  data-testid={item.testId}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-xs md:text-sm">{item.label}</span>
                </button>
              </Link>
            );
          })}
          
          <button
            onClick={handleLogout}
            className="flex flex-col md:flex-row items-center space-y-1 md:space-y-0 md:space-x-2 px-3 py-2 rounded-lg transition-colors text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20"
            data-testid="button-logout"
          >
            <LogOut className="w-5 h-5" />
            <span className="text-xs md:text-sm">Logout</span>
          </button>
        </div>
      </nav>
    </>
  );
}
