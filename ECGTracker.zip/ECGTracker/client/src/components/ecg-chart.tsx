import { useEffect, useRef } from "react";
import { Chart, ChartConfiguration } from "chart.js/auto";
import { useTheme } from "./theme-provider";

interface EcgChartProps {
  data: { x: number; y: number }[];
  type?: "line" | "area";
  className?: string;
}

export function EcgChart({ data, type = "line", className = "" }: EcgChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<Chart | null>(null);
  const { theme } = useTheme();

  useEffect(() => {
    if (!canvasRef.current || !data) return;

    // Destroy existing chart
    if (chartRef.current) {
      chartRef.current.destroy();
    }

    const ctx = canvasRef.current.getContext("2d");
    if (!ctx) return;

    const isDark = theme === "dark";
    const primaryColor = isDark ? "hsl(217.2, 91.2%, 59.8%)" : "hsl(221.2, 83.2%, 53.3%)";
    const backgroundColor = isDark ? "hsl(217.2, 91.2%, 59.8% / 0.1)" : "hsl(221.2, 83.2%, 53.3% / 0.1)";

    const config: ChartConfiguration = {
      type: "line",
      data: {
        datasets: [
          {
            label: "ECG",
            data: data,
            borderColor: primaryColor,
            backgroundColor: type === "area" ? backgroundColor : "transparent",
            borderWidth: 2,
            pointRadius: 0,
            tension: 0.1,
            fill: type === "area",
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          },
        },
        scales: {
          x: {
            display: false,
          },
          y: {
            display: false,
          },
        },
        animation: {
          duration: 2000,
          easing: "linear",
        },
      },
    };

    chartRef.current = new Chart(ctx, config);

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [data, type, theme]);

  return (
    <div className={`w-full h-full ${className}`}>
      <canvas ref={canvasRef} className="w-full h-full" />
    </div>
  );
}

interface TrendChartProps {
  labels: string[];
  data: number[];
  className?: string;
}

export function TrendChart({ labels, data, className = "" }: TrendChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<Chart | null>(null);
  const { theme } = useTheme();

  useEffect(() => {
    if (!canvasRef.current || !data || !labels) return;

    // Destroy existing chart
    if (chartRef.current) {
      chartRef.current.destroy();
    }

    const ctx = canvasRef.current.getContext("2d");
    if (!ctx) return;

    const isDark = theme === "dark";
    const secondaryColor = isDark ? "hsl(142.1, 70%, 45%)" : "hsl(142.1, 76.2%, 36.3%)";
    const backgroundColor = isDark ? "hsl(142.1, 70%, 45% / 0.1)" : "hsl(142.1, 76.2%, 36.3% / 0.1)";
    const gridColor = isDark ? "hsl(217.2, 32.6%, 17.5%)" : "hsl(214.3, 31.8%, 91.4%)";
    const textColor = isDark ? "hsl(215, 20.2%, 65.1%)" : "hsl(215.4, 16.3%, 46.9%)";

    const config: ChartConfiguration = {
      type: "line",
      data: {
        labels: labels,
        datasets: [
          {
            label: "Average Heart Rate",
            data: data,
            borderColor: secondaryColor,
            backgroundColor: backgroundColor,
            borderWidth: 3,
            pointBackgroundColor: secondaryColor,
            pointBorderColor: isDark ? "hsl(222.2, 84%, 7%)" : "#ffffff",
            pointBorderWidth: 2,
            pointRadius: 6,
            tension: 0.4,
            fill: true,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          },
        },
        scales: {
          y: {
            beginAtZero: false,
            min: Math.min(...data) - 5,
            max: Math.max(...data) + 5,
            grid: {
              color: gridColor,
            },
            ticks: {
              color: textColor,
            },
          },
          x: {
            grid: {
              display: false,
            },
            ticks: {
              color: textColor,
            },
          },
        },
      },
    };

    chartRef.current = new Chart(ctx, config);

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [labels, data, theme]);

  return (
    <div className={`w-full h-full ${className}`}>
      <canvas ref={canvasRef} className="w-full h-full" />
    </div>
  );
}
