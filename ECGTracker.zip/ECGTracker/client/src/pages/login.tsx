import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { HeartPulse } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { setStoredUser } from "@/lib/auth";
import { type User } from "@shared/schema";

interface LoginPageProps {
  onLogin: (user: User) => void;
}

export default function LoginPage({ onLogin }: LoginPageProps) {
  const [, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await apiRequest("POST", "/api/auth/login", formData);
      const { user } = await response.json();
      
      setStoredUser(user);
      onLogin(user);
      setLocation("/dashboard");
      
      toast({
        title: "Welcome back!",
        description: "You have successfully logged in.",
      });
    } catch (error) {
      toast({
        title: "Login failed",
        description: "Please check your credentials and try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 to-secondary/5 p-4">
      {/* Background pulse animations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-primary/5 rounded-full animate-pulse-slow" />
        <div 
          className="absolute bottom-1/4 right-1/4 w-48 h-48 bg-secondary/5 rounded-full animate-pulse-slow" 
          style={{ animationDelay: "1s" }}
        />
        <div 
          className="absolute top-1/2 right-1/3 w-32 h-32 bg-accent/5 rounded-full animate-pulse-slow"
          style={{ animationDelay: "2s" }}
        />
      </div>
      
      <div className="relative w-full max-w-md">
        <Card className="bg-card rounded-2xl shadow-2xl border border-border">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-2xl mb-4">
                <HeartPulse className="w-8 h-8 text-primary-foreground animate-ecg-wave" />
              </div>
              <h1 className="text-2xl font-semibold text-foreground">ECG Monitor</h1>
              <p className="text-muted-foreground mt-2">Sign in to your health dashboard</p>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="username" className="block text-sm font-medium text-foreground mb-2">
                  User ID
                </Label>
                <Input
                  id="username"
                  name="username"
                  type="text"
                  placeholder="Enter your user ID"
                  value={formData.username}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 bg-input border border-border rounded-lg focus:ring-2 focus:ring-ring focus:border-transparent transition-all"
                  required
                  data-testid="input-username"
                />
              </div>
              
              <div>
                <Label htmlFor="password" className="block text-sm font-medium text-foreground mb-2">
                  Password
                </Label>
                <Input
                  id="password"
                  name="password"
                  type="password"
                  placeholder="Enter your password"
                  value={formData.password}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 bg-input border border-border rounded-lg focus:ring-2 focus:ring-ring focus:border-transparent transition-all"
                  required
                  data-testid="input-password"
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-3 px-4 rounded-lg font-medium transition-colors"
                disabled={isLoading}
                data-testid="button-login"
              >
                {isLoading ? "Signing in..." : "Sign In"}
              </Button>
            </form>
            
            <div className="mt-6 text-center">
              <p className="text-primary hover:underline text-sm cursor-pointer">
                Demo credentials: any username with any password
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
