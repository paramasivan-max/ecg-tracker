import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, Activity, TrendingUp, History, User } from "lucide-react";
import { EcgChart } from "@/components/ecg-chart";
import { useLocation } from "wouter";
import { type User as UserType } from "@shared/schema";
import { mockEcgWaveform } from "@/lib/mock-data";

interface DashboardPageProps {
  user: UserType;
}

export default function DashboardPage({ user }: DashboardPageProps) {
  const [, setLocation] = useLocation();

  const { data: currentStats } = useQuery({
    queryKey: ["/api/users", user.id, "ecg-statistics"],
  });

  const { data: recentReadings = [] } = useQuery({
    queryKey: ["/api/users", user.id, "ecg-readings"],
  });

  const latestReading = Array.isArray(recentReadings) ? recentReadings[0] : undefined;
  const ecgWaveformData = mockEcgWaveform();

  const statusCards = [
    {
      title: "Heart Rate",
      value: latestReading ? `${latestReading.heartRate} BPM` : "-- BPM",
      status: "Normal Range",
      icon: Heart,
      color: "secondary",
      testId: "card-heart-rate",
    },
    {
      title: "ECG Status",
      value: latestReading?.status === "normal" ? "Normal" : latestReading?.status || "--",
      status: latestReading ? `Last reading: ${Math.round((Date.now() - new Date(latestReading.timestamp).getTime()) / 60000)} min ago` : "No recent readings",
      icon: Activity,
      color: "primary",
      testId: "card-ecg-status",
    },
    {
      title: "Today's Readings",
      value: (currentStats as any)?.totalReadings?.toString() || "--",
      status: "Total readings recorded",
      icon: TrendingUp,
      color: "accent",
      testId: "card-todays-readings",
    },
  ];

  return (
    <div className="min-h-screen bg-background pb-20 md:pt-20">
      <div className="container mx-auto px-4 py-6">
        {/* Welcome Header */}
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-semibold text-foreground" data-testid="text-welcome">
            Welcome back, {user.firstName || user.username}
          </h1>
          <p className="text-muted-foreground mt-1">Here's your current health status</p>
        </div>
        
        {/* Current Status Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {statusCards.map((card) => {
            const Icon = card.icon;
            const colorClasses = {
              secondary: "bg-secondary/10 text-secondary",
              primary: "bg-primary/10 text-primary",
              accent: "bg-accent/10 text-accent",
            };
            
            return (
              <Card key={card.title} className="bg-card rounded-xl border border-border shadow-sm" data-testid={card.testId}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-muted-foreground text-sm">{card.title}</p>
                      <p className="text-2xl font-semibold text-foreground" data-testid={`text-${card.title.toLowerCase().replace(/\s+/g, '-')}-value`}>
                        {card.value}
                      </p>
                    </div>
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${colorClasses[card.color as keyof typeof colorClasses]}`}>
                      <Icon className={`w-6 h-6 ${card.color === 'secondary' ? 'animate-pulse' : card.color === 'primary' ? 'animate-ecg-wave' : ''}`} />
                    </div>
                  </div>
                  <div className="mt-4">
                    <div className="flex items-center space-x-1">
                      <div className={`w-2 h-2 rounded-full ${card.color === 'secondary' ? 'bg-secondary' : card.color === 'primary' ? 'bg-primary' : 'bg-accent'}`} />
                      <span className="text-xs text-muted-foreground">{card.status}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
        
        {/* ECG Waveform Chart */}
        <Card className="bg-card rounded-xl border border-border shadow-sm mb-6">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-foreground">Live ECG Waveform</h2>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-secondary rounded-full animate-pulse" />
                <span className="text-sm text-muted-foreground">Live</span>
              </div>
            </div>
            <div className="h-64" data-testid="chart-ecg-waveform">
              <EcgChart data={ecgWaveformData} />
            </div>
          </CardContent>
        </Card>
        
        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Button
            onClick={() => setLocation("/history")}
            className="bg-primary hover:bg-primary/90 text-primary-foreground p-4 rounded-xl transition-colors flex items-center space-x-3 h-auto"
            data-testid="button-view-history"
          >
            <History className="w-5 h-5" />
            <span>View ECG History</span>
          </Button>
          <Button
            onClick={() => setLocation("/profile")}
            className="bg-secondary hover:bg-secondary/90 text-secondary-foreground p-4 rounded-xl transition-colors flex items-center space-x-3 h-auto"
            data-testid="button-update-profile"
          >
            <User className="w-5 h-5" />
            <span>Update Profile</span>
          </Button>
        </div>
      </div>
    </div>
  );
}
