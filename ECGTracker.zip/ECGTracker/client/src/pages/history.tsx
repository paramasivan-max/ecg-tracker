import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Download } from "lucide-react";
import { TrendChart } from "@/components/ecg-chart";
import { type User } from "@shared/schema";
import { mockHeartRateTrend, generateCsvData, downloadCsv } from "@/lib/mock-data";
import { format } from "date-fns";

interface HistoryPageProps {
  user: User;
}

export default function HistoryPage({ user }: HistoryPageProps) {
  const [dateFilter, setDateFilter] = useState("");

  const { data: statistics } = useQuery({
    queryKey: ["/api/users", user.id, "ecg-statistics"],
  });

  const { data: readings = [] } = useQuery({
    queryKey: ["/api/users", user.id, "ecg-readings"],
  });

  const trendData = mockHeartRateTrend();

  const filteredReadings = dateFilter
    ? (readings as any[]).filter((reading: any) => 
        format(new Date(reading.timestamp), 'yyyy-MM-dd') === dateFilter
      )
    : (readings as any[]);

  const handleExport = () => {
    const csvContent = generateCsvData(filteredReadings);
    downloadCsv(csvContent, `ecg_history_${dateFilter || 'all'}.csv`);
  };

  const getStatusBadge = (status: string) => {
    const baseClasses = "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium";
    
    switch (status) {
      case "normal":
        return `${baseClasses} bg-secondary/10 text-secondary`;
      case "elevated":
        return `${baseClasses} bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400`;
      case "low":
        return `${baseClasses} bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400`;
      default:
        return `${baseClasses} bg-muted text-muted-foreground`;
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffInDays === 0) {
      return `Today, ${format(date, 'h:mm a')}`;
    } else if (diffInDays === 1) {
      return `Yesterday, ${format(date, 'h:mm a')}`;
    } else {
      return format(date, 'MMM d, h:mm a');
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20 md:pt-20">
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <h1 className="text-2xl md:text-3xl font-semibold text-foreground mb-4 md:mb-0">
            ECG History
          </h1>
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
            <Input
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="px-4 py-2 bg-input border border-border rounded-lg focus:ring-2 focus:ring-ring"
              data-testid="input-date-filter"
            />
            <Button
              onClick={handleExport}
              className="bg-accent hover:bg-accent/90 text-accent-foreground px-4 py-2 rounded-lg transition-colors flex items-center space-x-2"
              data-testid="button-export"
            >
              <Download className="w-4 h-4" />
              <span>Export CSV</span>
            </Button>
          </div>
        </div>
        
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-card rounded-xl border border-border shadow-sm">
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-muted-foreground text-sm">Total Readings</p>
                <p className="text-xl font-semibold text-foreground" data-testid="text-total-readings">
                  {(statistics as any)?.totalReadings || 0}
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-card rounded-xl border border-border shadow-sm">
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-muted-foreground text-sm">Avg Heart Rate</p>
                <p className="text-xl font-semibold text-foreground" data-testid="text-avg-heart-rate">
                  {(statistics as any)?.avgHeartRate || 0} BPM
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-card rounded-xl border border-border shadow-sm">
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-muted-foreground text-sm">Normal Readings</p>
                <p className="text-xl font-semibold text-secondary" data-testid="text-normal-readings">
                  {statistics ? Math.round(((statistics as any).normalReadings / (statistics as any).totalReadings) * 100) : 0}%
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-card rounded-xl border border-border shadow-sm">
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-muted-foreground text-sm">Anomalies</p>
                <p className="text-xl font-semibold text-orange-500" data-testid="text-anomalies">
                  {(statistics as any)?.anomalies || 0}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* History Chart */}
        <Card className="bg-card rounded-xl border border-border shadow-sm mb-6">
          <CardContent className="p-6">
            <h2 className="text-lg font-semibold text-foreground mb-6">
              Heart Rate Trend (Last 7 Days)
            </h2>
            <div className="h-64" data-testid="chart-history-trend">
              <TrendChart labels={trendData.labels} data={trendData.data} />
            </div>
          </CardContent>
        </Card>
        
        {/* History Table */}
        <Card className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
          <div className="p-6 border-b border-border">
            <h2 className="text-lg font-semibold text-foreground">
              Recent Readings {dateFilter && `(${format(new Date(dateFilter), 'MMM d, yyyy')})`}
            </h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full" data-testid="table-readings">
              <thead className="bg-muted">
                <tr>
                  <th className="text-left py-3 px-6 text-sm font-medium text-muted-foreground">
                    Date & Time
                  </th>
                  <th className="text-left py-3 px-6 text-sm font-medium text-muted-foreground">
                    Heart Rate
                  </th>
                  <th className="text-left py-3 px-6 text-sm font-medium text-muted-foreground">
                    Status
                  </th>
                  <th className="text-left py-3 px-6 text-sm font-medium text-muted-foreground">
                    Duration
                  </th>
                  <th className="text-left py-3 px-6 text-sm font-medium text-muted-foreground">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filteredReadings.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 px-6 text-center text-muted-foreground">
                      {dateFilter ? "No readings found for the selected date." : "No ECG readings available."}
                    </td>
                  </tr>
                ) : (
                  filteredReadings.map((reading: any) => (
                    <tr key={reading.id} className="hover:bg-muted/50" data-testid={`row-reading-${reading.id}`}>
                      <td className="py-4 px-6 text-sm text-foreground">
                        {formatTimestamp(reading.timestamp)}
                      </td>
                      <td className="py-4 px-6 text-sm text-foreground">
                        {reading.heartRate} BPM
                      </td>
                      <td className="py-4 px-6">
                        <span className={getStatusBadge(reading.status)}>
                          {reading.status.charAt(0).toUpperCase() + reading.status.slice(1)}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-sm text-muted-foreground">
                        {reading.duration}s
                      </td>
                      <td className="py-4 px-6">
                        <button 
                          className="text-primary hover:underline text-sm"
                          data-testid={`button-view-details-${reading.id}`}
                        >
                          View Details
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}
