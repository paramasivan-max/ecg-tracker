import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  age: integer("age"),
  deviceId: text("device_id"),
  medicalConditions: text("medical_conditions"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const ecgReadings = pgTable("ecg_readings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  heartRate: integer("heart_rate").notNull(),
  status: text("status").notNull(), // 'normal', 'elevated', 'low'
  duration: integer("duration").notNull(), // in seconds
  waveformData: jsonb("waveform_data"), // ECG waveform points
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  firstName: true,
  lastName: true,
  age: true,
  deviceId: true,
  medicalConditions: true,
});

export const insertEcgReadingSchema = createInsertSchema(ecgReadings).pick({
  userId: true,
  heartRate: true,
  status: true,
  duration: true,
  waveformData: true,
});

export const updateUserFormSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Valid email is required"),
  age: z.string().optional(),
  deviceId: z.string().optional(),
  medicalConditions: z.string().optional(),
});

export const updateUserSchema = insertUserSchema.partial().extend({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Valid email is required"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertEcgReading = z.infer<typeof insertEcgReadingSchema>;
export type EcgReading = typeof ecgReadings.$inferSelect;
