import { type User, type InsertUser, type EcgReading, type InsertEcgReading } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined>;
  
  // ECG reading methods
  getEcgReadings(userId: string, limit?: number): Promise<EcgReading[]>;
  getEcgReading(id: string): Promise<EcgReading | undefined>;
  createEcgReading(reading: InsertEcgReading): Promise<EcgReading>;
  getEcgStatistics(userId: string): Promise<{
    totalReadings: number;
    avgHeartRate: number;
    normalReadings: number;
    anomalies: number;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private ecgReadings: Map<string, EcgReading>;

  constructor() {
    this.users = new Map();
    this.ecgReadings = new Map();
    this.initializeMockData();
  }

  private initializeMockData() {
    // Create a demo user
    const demoUser: User = {
      id: "user-demo-123",
      username: "demo",
      email: "demo@ecgmonitor.com",
      firstName: "Dr. Sarah",
      lastName: "Smith",
      age: 34,
      deviceId: "SW-2024-7891",
      medicalConditions: "None reported",
      createdAt: new Date("2024-01-01"),
    };
    this.users.set(demoUser.id, demoUser);

    // Create some demo ECG readings
    const now = new Date();
    const readings: EcgReading[] = [
      {
        id: randomUUID(),
        userId: demoUser.id,
        heartRate: 72,
        status: "normal",
        duration: 30,
        waveformData: this.generateEcgWaveform(),
        timestamp: new Date(now.getTime() - 2 * 60 * 1000), // 2 minutes ago
      },
      {
        id: randomUUID(),
        userId: demoUser.id,
        heartRate: 68,
        status: "normal",
        duration: 45,
        waveformData: this.generateEcgWaveform(),
        timestamp: new Date(now.getTime() - 3 * 60 * 60 * 1000), // 3 hours ago
      },
      {
        id: randomUUID(),
        userId: demoUser.id,
        heartRate: 85,
        status: "elevated",
        duration: 60,
        waveformData: this.generateEcgWaveform(),
        timestamp: new Date(now.getTime() - 24 * 60 * 60 * 1000), // 1 day ago
      },
      {
        id: randomUUID(),
        userId: demoUser.id,
        heartRate: 74,
        status: "normal",
        duration: 30,
        waveformData: this.generateEcgWaveform(),
        timestamp: new Date(now.getTime() - 25 * 60 * 60 * 1000), // 1 day ago
      },
      {
        id: randomUUID(),
        userId: demoUser.id,
        heartRate: 70,
        status: "normal",
        duration: 35,
        waveformData: this.generateEcgWaveform(),
        timestamp: new Date(now.getTime() - 26 * 60 * 60 * 1000), // 1 day ago
      },
    ];

    readings.forEach(reading => this.ecgReadings.set(reading.id, reading));
  }

  private generateEcgWaveform() {
    const data = [];
    for (let i = 0; i < 100; i++) {
      let value = 0;
      if (i % 20 === 15) value = 0.8; // R peak
      else if (i % 20 === 14 || i % 20 === 16) value = -0.2; // Q and S
      else if (i % 20 === 17) value = 0.3; // T wave
      else value = Math.random() * 0.1 - 0.05; // baseline noise
      
      data.push({ x: i, y: value });
    }
    return data;
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser,
      id,
      age: insertUser.age ?? null,
      deviceId: insertUser.deviceId ?? null,
      medicalConditions: insertUser.medicalConditions ?? null,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getEcgReadings(userId: string, limit?: number): Promise<EcgReading[]> {
    const readings = Array.from(this.ecgReadings.values())
      .filter(reading => reading.userId === userId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    
    return limit ? readings.slice(0, limit) : readings;
  }

  async getEcgReading(id: string): Promise<EcgReading | undefined> {
    return this.ecgReadings.get(id);
  }

  async createEcgReading(insertReading: InsertEcgReading): Promise<EcgReading> {
    const id = randomUUID();
    const reading: EcgReading = {
      ...insertReading,
      id,
      waveformData: insertReading.waveformData ?? null,
      timestamp: new Date(),
    };
    this.ecgReadings.set(id, reading);
    return reading;
  }

  async getEcgStatistics(userId: string): Promise<{
    totalReadings: number;
    avgHeartRate: number;
    normalReadings: number;
    anomalies: number;
  }> {
    const readings = await this.getEcgReadings(userId);
    const totalReadings = readings.length;
    const avgHeartRate = readings.reduce((sum, r) => sum + r.heartRate, 0) / totalReadings;
    const normalReadings = readings.filter(r => r.status === 'normal').length;
    const anomalies = readings.filter(r => r.status !== 'normal').length;

    return {
      totalReadings,
      avgHeartRate: Math.round(avgHeartRate),
      normalReadings,
      anomalies,
    };
  }
}

export const storage = new MemStorage();
